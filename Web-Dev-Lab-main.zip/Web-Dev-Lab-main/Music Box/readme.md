## Practical 6
